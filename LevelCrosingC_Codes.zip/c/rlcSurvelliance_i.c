/* WARNING if type checker is not performed, translation could contain errors ! */

#include "rlcSurvelliance.h"

/* Clause SEES */
#include "Context.h"

/* Clause CONCRETE_CONSTANTS */
/* Basic constants */

/* Array and record constants */
/* Clause CONCRETE_VARIABLES */

static Context__RLC_STATE rlcSurvelliance__rlcState;
/* Clause INITIALISATION */
void rlcSurvelliance__INITIALISATION(void)
{
    
    rlcSurvelliance__rlcState = Context__nullRlcState;
}

/* Clause OPERATIONS */

void rlcSurvelliance__rlc_state(int32_t rlcParameter)
{
    if(rlcParameter == 1)
    {
        rlcSurvelliance__rlcState = Context__unclear;
    }
    else
    {
        rlcSurvelliance__rlcState = Context__clear;
    }
}

void rlcSurvelliance__output_rlcState(Context__RLC_STATE *rlcstate)
{
    (*rlcstate) = rlcSurvelliance__rlcState;
}

