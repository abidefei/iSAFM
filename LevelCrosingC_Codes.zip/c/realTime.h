#ifndef _realTime_h
#define _realTime_h

#include <stdint.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


/* Clause SETS */

/* Clause CONCRETE_VARIABLES */


/* Clause CONCRETE_CONSTANTS */
/* Basic constants */
/* Array and record constants */
extern void realTime__INITIALISATION(void);

/* Clause OPERATIONS */

extern void realTime__Time(void);
extern void realTime__tickTock(void);
extern void realTime__outputTime(int32_t *time);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* _realTime_h */
