#ifndef _Context_h
#define _Context_h

#include <stdint.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


/* Clause SETS */
typedef enum
{
    Context__enBarrier,
    Context__exBarrier
    
} Context__BARRIERS;
#define Context__BARRIERS__max 2
typedef enum
{
    Context__upNullCmd,
    Context__upBraking,
    Context__upKeepgoing,
    Context__downNullCmd,
    Context__downBraking,
    Context__downKeepgoing
    
} Context__COMMANDS;
#define Context__COMMANDS__max 6
typedef enum
{
    Context__closing,
    Context__closed,
    Context__opening,
    Context__open
    
} Context__BARRIER_STATE;
#define Context__BARRIER_STATE__max 4
typedef enum
{
    Context__nullRlcState,
    Context__unclear,
    Context__clear
    
} Context__RLC_STATE;
#define Context__RLC_STATE__max 3
typedef enum
{
    Context__upInitialisation,
    Context__downInitialisation,
    Context__upApproaching,
    Context__upClosing,
    Context__upExit,
    Context__downApproaching,
    Context__downClosing,
    Context__downExit
    
} Context__TRAIN_POSITION;
#define Context__TRAIN_POSITION__max 8
typedef enum
{
    Context__upTrain,
    Context__downTrain
    
} Context__TRAIN_NUMBER;
#define Context__TRAIN_NUMBER__max 2
typedef enum
{
    Context__enWhite,
    Context__enRed,
    Context__enRedflash,
    Context__exitWhite,
    Context__exitRed,
    Context__exitRedflash
    
} Context__SIGNAL;
#define Context__SIGNAL__max 6
typedef enum
{
    Context__upMA,
    Context__upBackMA,
    Context__upNullMA,
    Context__downMA,
    Context__downBackMA,
    Context__downNullMA
    
} Context__TRAIN_MA;
#define Context__TRAIN_MA__max 6

/* Clause CONCRETE_VARIABLES */


/* Clause CONCRETE_CONSTANTS */
/* Basic constants */
/* Array and record constants */
extern void Context__INITIALISATION(void);


#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* _Context_h */
