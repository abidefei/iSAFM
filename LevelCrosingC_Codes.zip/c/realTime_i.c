/* WARNING if type checker is not performed, translation could contain errors ! */

#include "realTime.h"

/* Clause CONCRETE_CONSTANTS */
/* Basic constants */

/* Array and record constants */
/* Clause CONCRETE_VARIABLES */

static int32_t realTime__currentTime;
/* Clause INITIALISATION */
void realTime__INITIALISATION(void)
{
    
    realTime__currentTime = 0;
}

/* Clause OPERATIONS */

void realTime__Time(void)
{
    realTime__currentTime = 1;
}

void realTime__tickTock(void)
{
    realTime__currentTime = realTime__currentTime+1;
}

void realTime__outputTime(int32_t *time)
{
    (*time) = realTime__currentTime;
}

