/* WARNING if type checker is not performed, translation could contain errors ! */

#include "trainMoveAuthority.h"

/* Clause SEES */
#include "Context.h"

/* Clause CONCRETE_CONSTANTS */
/* Basic constants */

/* Array and record constants */
/* Clause CONCRETE_VARIABLES */

static Context__TRAIN_MA trainMoveAuthority__trainMA[2];
/* Clause INITIALISATION */
void trainMoveAuthority__INITIALISATION(void)
{
    
    unsigned int i = 0;
    for(i = 0; i <= Context__TRAIN_NUMBER__max-1;i++)
    {
        trainMoveAuthority__trainMA[i] = Context__upNullMA;
    }
}

/* Clause OPERATIONS */

void trainMoveAuthority__upAllow(void)
{
    trainMoveAuthority__trainMA[Context__upTrain] = Context__upMA;
}

void trainMoveAuthority__downAllow(void)
{
    trainMoveAuthority__trainMA[Context__downTrain] = Context__downMA;
}

void trainMoveAuthority__upBan(void)
{
    trainMoveAuthority__trainMA[Context__upTrain] = Context__upBackMA;
}

void trainMoveAuthority__downBan(void)
{
    trainMoveAuthority__trainMA[Context__downTrain] = Context__downBackMA;
}

void trainMoveAuthority__upAgainAllow(void)
{
    Context__TRAIN_MA localUpTrainMA;
    
    localUpTrainMA = trainMoveAuthority__trainMA[Context__upTrain];
    if(localUpTrainMA == Context__upBackMA)
    {
        trainMoveAuthority__trainMA[Context__upTrain] = Context__upMA;
    }
}

void trainMoveAuthority__downAgainAllow(void)
{
    Context__TRAIN_MA localDownTrainMA;
    
    localDownTrainMA = trainMoveAuthority__trainMA[Context__downTrain];
    if(localDownTrainMA == Context__downBackMA)
    {
        trainMoveAuthority__trainMA[Context__downTrain] = Context__downMA;
    }
}

void trainMoveAuthority__outputMA(Context__TRAIN_MA *outputUpMA, Context__TRAIN_MA *outputDownMA)
{
    (*outputUpMA) = trainMoveAuthority__trainMA[Context__upTrain];
    (*outputDownMA) = trainMoveAuthority__trainMA[Context__downTrain];
}

