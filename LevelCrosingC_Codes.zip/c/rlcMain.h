#ifndef _rlcMain_h
#define _rlcMain_h

#include <stdint.h>
#include <stdbool.h>
/* Clause SEES */
#include "Context.h"

/* Clause INCLUDES */
#include "barrierStates.h"
#include "trainMoveAuthority.h"

/* Clause IMPORTS */
#include "barrierStates.h"
#include "trainMoveAuthority.h"
#define rlcMain__tickTock barrierStates__tickTock
#define rlcMain__Rlc_state barrierStates__Rlc_state
#define rlcMain__upAgainAllow trainMoveAuthority__upAgainAllow
#define rlcMain__downAgainAllow trainMoveAuthority__downAgainAllow

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


/* Clause SETS */

/* Clause CONCRETE_VARIABLES */


/* Clause CONCRETE_CONSTANTS */
/* Basic constants */
/* Array and record constants */
extern void rlcMain__INITIALISATION(void);

/* Clause OPERATIONS */

extern void rlcMain__upTrainPositionChange(Context__TRAIN_POSITION upSensorFlag);
extern void rlcMain__downTrainPositionChange(Context__TRAIN_POSITION downSensorFlag);
extern void rlcMain__entranceClosedChange(int32_t enActParameter);
extern void rlcMain__exitClosingChange(void);
extern void rlcMain__exitClosedChange(int32_t exActParameter);
extern void rlcMain__enExOpeningChange(void);
extern void rlcMain__entranceOpenChange(int32_t enActParameter);
extern void rlcMain__exitOpenChange(int32_t exActParameter);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* _rlcMain_h */
