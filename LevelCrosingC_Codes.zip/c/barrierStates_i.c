/* WARNING if type checker is not performed, translation could contain errors ! */

#include "barrierStates.h"

/* Clause SEES */
#include "Context.h"

/* Clause IMPORTS */
#include "realTime.h"
#include "rlcSurvelliance.h"

/* Clause CONCRETE_CONSTANTS */
/* Basic constants */

/* Array and record constants */
/* Clause CONCRETE_VARIABLES */

static Context__BARRIER_STATE barrierStates__barrierState[2];
/* Clause INITIALISATION */
void barrierStates__INITIALISATION(void)
{
    
    unsigned int i = 0;
    realTime__INITIALISATION();
    rlcSurvelliance__INITIALISATION();
    for(i = 0; i <= Context__BARRIERS__max-1;i++)
    {
        barrierStates__barrierState[i] = Context__open;
    }
}

/* Clause OPERATIONS */

void barrierStates__enBarrierOpen(int32_t enActParameter)
{
    {
        Context__BARRIER_STATE localEnBarrierState;
        int32_t localTime;
        
        localEnBarrierState = barrierStates__barrierState[Context__enBarrier];
        realTime__outputTime(&localTime);
        if(((localEnBarrierState == Context__opening) &&
            (enActParameter == 1)) &&
        ((localTime) >= (7)))
        {
            barrierStates__barrierState[Context__enBarrier] = Context__open;
        }
    }
}

void barrierStates__exBarrierOpen(int32_t exActParameter)
{
    {
        Context__BARRIER_STATE localExBarrierState;
        int32_t localTime;
        
        localExBarrierState = barrierStates__barrierState[Context__exBarrier];
        realTime__outputTime(&localTime);
        if(((localExBarrierState == Context__opening) &&
            (exActParameter == 1)) &&
        ((localTime) >= (7)))
        {
            barrierStates__barrierState[Context__exBarrier] = Context__open;
        }
    }
}

void barrierStates__enExBarrierOpening(void)
{
    unsigned int i = 0;
    {
        {
            Context__BARRIER_STATE localEnBarrierState;
            Context__BARRIER_STATE localExBarrierState;
            
            localEnBarrierState = barrierStates__barrierState[Context__enBarrier];
            localExBarrierState = barrierStates__barrierState[Context__exBarrier];
            if((localEnBarrierState == Context__closed) &&
            (localExBarrierState == Context__closed))
            {
                for(i = 0; i <= Context__BARRIERS__max-1;i++)
                {
                    barrierStates__barrierState[i] = Context__opening;
                }
                realTime__Time();
                rlcSurvelliance__rlc_state(1);
            }
        }
    }
}

void barrierStates__enBarrierClosing(void)
{
    {
        Context__BARRIER_STATE localEnBarrierState;
        
        localEnBarrierState = barrierStates__barrierState[Context__enBarrier];
        if(localEnBarrierState == Context__open)
        {
            barrierStates__barrierState[Context__enBarrier] = Context__closing;
            realTime__Time();
        }
    }
}

void barrierStates__exBarrierClosing(void)
{
    {
        Context__BARRIER_STATE localExBarrierState;
        Context__RLC_STATE localRlcState;
        
        localExBarrierState = barrierStates__barrierState[Context__exBarrier];
        rlcSurvelliance__output_rlcState(&localRlcState);
        if((localExBarrierState == Context__open) &&
        (localRlcState == Context__clear))
        {
            barrierStates__barrierState[Context__exBarrier] = Context__closing;
            realTime__Time();
        }
    }
}

void barrierStates__enBarrierClosed(int32_t enActParameter)
{
    {
        Context__BARRIER_STATE localEnBarrierState;
        int32_t localTime;
        
        localEnBarrierState = barrierStates__barrierState[Context__enBarrier];
        realTime__outputTime(&localTime);
        if(((localEnBarrierState == Context__closing) &&
            (enActParameter == 1)) &&
        ((localTime) >= (7)))
        {
            barrierStates__barrierState[Context__enBarrier] = Context__closed;
        }
    }
}

void barrierStates__exBarrierClosed(int32_t exActParameter)
{
    {
        Context__BARRIER_STATE localExBarrierState;
        int32_t localTime;
        
        localExBarrierState = barrierStates__barrierState[Context__exBarrier];
        realTime__outputTime(&localTime);
        if(((localExBarrierState == Context__closing) &&
            (exActParameter == 1)) &&
        ((localTime) >= (7)))
        {
            barrierStates__barrierState[Context__exBarrier] = Context__closed;
        }
    }
}

void barrierStates__outputBarrierState(Context__BARRIER_STATE *enState, Context__BARRIER_STATE *exState)
{
    (*enState) = barrierStates__barrierState[Context__enBarrier];
    (*exState) = barrierStates__barrierState[Context__exBarrier];
}

void barrierStates__Rlc_state(int32_t rlcParameter)
{
    {
        Context__BARRIER_STATE localEnBarrierState;
        Context__RLC_STATE localRlcState;
        
        localEnBarrierState = barrierStates__barrierState[Context__enBarrier];
        rlcSurvelliance__output_rlcState(&localRlcState);
        if((localEnBarrierState == Context__closed) &&
        ((localRlcState) != (Context__clear)))
        {
            rlcSurvelliance__rlc_state(rlcParameter);
        }
    }
}

void barrierStates__outputRlc(Context__RLC_STATE *rlc)
{
    rlcSurvelliance__output_rlcState(rlc);
}

