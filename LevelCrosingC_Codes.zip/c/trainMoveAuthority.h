#ifndef _trainMoveAuthority_h
#define _trainMoveAuthority_h

#include <stdint.h>
#include <stdbool.h>
/* Clause SEES */
#include "Context.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


/* Clause SETS */

/* Clause CONCRETE_VARIABLES */


/* Clause CONCRETE_CONSTANTS */
/* Basic constants */
/* Array and record constants */
extern void trainMoveAuthority__INITIALISATION(void);

/* Clause OPERATIONS */

extern void trainMoveAuthority__upAllow(void);
extern void trainMoveAuthority__downAllow(void);
extern void trainMoveAuthority__upBan(void);
extern void trainMoveAuthority__downBan(void);
extern void trainMoveAuthority__upAgainAllow(void);
extern void trainMoveAuthority__downAgainAllow(void);
extern void trainMoveAuthority__outputMA(Context__TRAIN_MA *outputUpMA, Context__TRAIN_MA *outputDownMA);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* _trainMoveAuthority_h */
