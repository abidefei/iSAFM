#ifndef _rlcSurvelliance_h
#define _rlcSurvelliance_h

#include <stdint.h>
#include <stdbool.h>
/* Clause SEES */
#include "Context.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


/* Clause SETS */

/* Clause CONCRETE_VARIABLES */


/* Clause CONCRETE_CONSTANTS */
/* Basic constants */
/* Array and record constants */
extern void rlcSurvelliance__INITIALISATION(void);

/* Clause OPERATIONS */

extern void rlcSurvelliance__rlc_state(int32_t rlcParameter);
extern void rlcSurvelliance__output_rlcState(Context__RLC_STATE *rlcstate);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* _rlcSurvelliance_h */
