#ifndef _barrierStates_h
#define _barrierStates_h

#include <stdint.h>
#include <stdbool.h>
/* Clause SEES */
#include "Context.h"

/* Clause INCLUDES */
#include "realTime.h"
#include "rlcSurvelliance.h"

/* Clause IMPORTS */
#include "realTime.h"
#include "rlcSurvelliance.h"
#define barrierStates__tickTock realTime__tickTock

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


/* Clause SETS */

/* Clause CONCRETE_VARIABLES */


/* Clause CONCRETE_CONSTANTS */
/* Basic constants */
/* Array and record constants */
extern void barrierStates__INITIALISATION(void);

/* Clause OPERATIONS */

extern void barrierStates__enBarrierOpen(int32_t enActParameter);
extern void barrierStates__exBarrierOpen(int32_t exActParameter);
extern void barrierStates__enExBarrierOpening(void);
extern void barrierStates__enBarrierClosing(void);
extern void barrierStates__exBarrierClosing(void);
extern void barrierStates__enBarrierClosed(int32_t enActParameter);
extern void barrierStates__exBarrierClosed(int32_t exActParameter);
extern void barrierStates__outputBarrierState(Context__BARRIER_STATE *enState, Context__BARRIER_STATE *exState);
extern void barrierStates__Rlc_state(int32_t rlcParameter);
extern void barrierStates__outputRlc(Context__RLC_STATE *rlc);

#ifdef __cplusplus
}
#endif /* __cplusplus */


#endif /* _barrierStates_h */
