/* WARNING if type checker is not performed, translation could contain errors ! */

#include "rlcMain.h"

/* Clause SEES */
#include "Context.h"

/* Clause IMPORTS */
#include "barrierStates.h"
#include "trainMoveAuthority.h"

/* Clause CONCRETE_CONSTANTS */
/* Basic constants */

/* Array and record constants */
/* Clause CONCRETE_VARIABLES */

static Context__TRAIN_POSITION rlcMain__trainPosition_r[2];
static Context__COMMANDS rlcMain__command_r[2];
static Context__SIGNAL rlcMain__enSignal;
static Context__SIGNAL rlcMain__exitSignal;
/* Clause INITIALISATION */
void rlcMain__INITIALISATION(void)
{
    
    unsigned int i = 0;
    barrierStates__INITIALISATION();
    trainMoveAuthority__INITIALISATION();
    for(i = 0; i <= Context__TRAIN_NUMBER__max-1;i++)
    {
        rlcMain__trainPosition_r[i] = Context__upInitialisation;
    }
    for(i = 0; i <= Context__TRAIN_NUMBER__max-1;i++)
    {
        rlcMain__command_r[i] = Context__upNullCmd;
    }
    rlcMain__enSignal = Context__enWhite;
    rlcMain__exitSignal = Context__exitWhite;
}

/* Clause OPERATIONS */

void rlcMain__upTrainPositionChange(Context__TRAIN_POSITION upSensorFlag)
{
    {
        Context__TRAIN_POSITION localTrainPosition;
        Context__TRAIN_POSITION localDownTrainPosition;
        Context__COMMANDS localCmd;
        Context__BARRIER_STATE localEnBarrier;
        Context__BARRIER_STATE localExBarrier;
        Context__RLC_STATE localRlc;
        Context__TRAIN_MA localUpTrainMA;
        Context__TRAIN_MA localDownTrainMA;
        
        localTrainPosition = rlcMain__trainPosition_r[Context__upTrain];
        localDownTrainPosition = rlcMain__trainPosition_r[Context__downTrain];
        localCmd = rlcMain__command_r[Context__upTrain];
        barrierStates__outputBarrierState(&localEnBarrier, &localExBarrier);
        barrierStates__outputRlc(&localRlc);
        trainMoveAuthority__outputMA(&localUpTrainMA, &localDownTrainMA);
        if(((upSensorFlag == Context__upApproaching) &&
            (localTrainPosition == Context__upInitialisation)) &&
        ((localDownTrainPosition) != (Context__downExit)))
        {
            rlcMain__trainPosition_r[Context__upTrain] = upSensorFlag;
            barrierStates__enBarrierClosing();
            trainMoveAuthority__upAllow();
            rlcMain__enSignal = Context__enRed;
        }
        else if(((((((upSensorFlag == Context__upClosing) &&
                            (localTrainPosition == Context__upApproaching)) &&
                        (localCmd == Context__upNullCmd)) &&
                    (localEnBarrier == Context__closed)) &&
                (localExBarrier == Context__closed)) &&
            (localRlc == Context__clear)) &&
        (localUpTrainMA == Context__upMA))
        {
            rlcMain__trainPosition_r[Context__upTrain] = upSensorFlag;
            rlcMain__command_r[Context__upTrain] = Context__upKeepgoing;
            rlcMain__enSignal = Context__enRedflash;
            rlcMain__exitSignal = Context__exitRedflash;
        }
        else if((((upSensorFlag == Context__upClosing) &&
                (localTrainPosition == Context__upApproaching)) &&
            (localCmd == Context__upNullCmd)) &&
        (!((((localEnBarrier == Context__closed) &&
                        (localExBarrier == Context__closed)) &&
                    (localRlc == Context__clear)) &&
                (localUpTrainMA == Context__upMA))))
        {
            rlcMain__trainPosition_r[Context__upTrain] = upSensorFlag;
            rlcMain__command_r[Context__upTrain] = Context__upBraking;
            trainMoveAuthority__upBan();
            rlcMain__enSignal = Context__enRedflash;
            rlcMain__exitSignal = Context__exitRedflash;
        }
        else if(((upSensorFlag == Context__upExit) &&
            (localTrainPosition == Context__upClosing)) &&
        (localCmd == Context__upKeepgoing))
        {
            rlcMain__trainPosition_r[Context__upTrain] = upSensorFlag;
        }
        else if((((localTrainPosition == Context__upExit) &&
                (((localEnBarrier == Context__open) ||
                        (localEnBarrier == Context__closed)))) &&
            (((localExBarrier == Context__open) ||
                    (localExBarrier == Context__closed)))) &&
        (localCmd == Context__upKeepgoing))
        {
            rlcMain__trainPosition_r[Context__upTrain] = Context__upInitialisation;
            rlcMain__command_r[Context__upTrain] = Context__upNullCmd;
            trainMoveAuthority__upBan();
        }
    }
}

void rlcMain__downTrainPositionChange(Context__TRAIN_POSITION downSensorFlag)
{
    {
        Context__TRAIN_POSITION localTrainPosition;
        Context__TRAIN_POSITION localUpTrainPosition;
        Context__COMMANDS localCmd;
        Context__BARRIER_STATE localEnBarrier;
        Context__BARRIER_STATE localExBarrier;
        Context__RLC_STATE localRlc;
        Context__TRAIN_MA localUpTrainMA;
        Context__TRAIN_MA localDownTrainMA;
        
        localTrainPosition = rlcMain__trainPosition_r[Context__downTrain];
        localUpTrainPosition = rlcMain__trainPosition_r[Context__upTrain];
        localCmd = rlcMain__command_r[Context__downTrain];
        barrierStates__outputBarrierState(&localEnBarrier, &localExBarrier);
        barrierStates__outputRlc(&localRlc);
        trainMoveAuthority__outputMA(&localUpTrainMA, &localDownTrainMA);
        if(((downSensorFlag == Context__downApproaching) &&
            (localTrainPosition == Context__downInitialisation)) &&
        ((localUpTrainPosition) != (Context__upExit)))
        {
            rlcMain__trainPosition_r[Context__downTrain] = downSensorFlag;
            barrierStates__enBarrierClosing();
            trainMoveAuthority__downAllow();
            rlcMain__exitSignal = Context__exitRed;
        }
        else if(((((((downSensorFlag == Context__downClosing) &&
                            (localTrainPosition == Context__downApproaching)) &&
                        (localCmd == Context__downNullCmd)) &&
                    (localEnBarrier == Context__closed)) &&
                (localExBarrier == Context__closed)) &&
            (localRlc == Context__clear)) &&
        (localDownTrainMA == Context__downMA))
        {
            rlcMain__trainPosition_r[Context__downTrain] = downSensorFlag;
            rlcMain__command_r[Context__downTrain] = Context__downKeepgoing;
            rlcMain__enSignal = Context__enRedflash;
            rlcMain__exitSignal = Context__exitRedflash;
        }
        else if((((downSensorFlag == Context__downClosing) &&
                (localTrainPosition == Context__downApproaching)) &&
            (localCmd == Context__downNullCmd)) &&
        (!((((localEnBarrier == Context__closed) &&
                        (localExBarrier == Context__closed)) &&
                    (localRlc == Context__clear)) &&
                (localDownTrainMA == Context__downMA))))
        {
            rlcMain__trainPosition_r[Context__downTrain] = downSensorFlag;
            rlcMain__command_r[Context__downTrain] = Context__downBraking;
            trainMoveAuthority__downBan();
            rlcMain__enSignal = Context__enRedflash;
            rlcMain__exitSignal = Context__exitRedflash;
        }
        else if(((downSensorFlag == Context__downExit) &&
            (localTrainPosition == Context__downClosing)) &&
        (localCmd == Context__downKeepgoing))
        {
            rlcMain__trainPosition_r[Context__downTrain] = downSensorFlag;
        }
        else if((((localTrainPosition == Context__downExit) &&
                (((localEnBarrier == Context__open) ||
                        (localEnBarrier == Context__closed)))) &&
            (((localExBarrier == Context__open) ||
                    (localExBarrier == Context__closed)))) &&
        (localCmd == Context__downKeepgoing))
        {
            rlcMain__trainPosition_r[Context__downTrain] = Context__downInitialisation;
            rlcMain__command_r[Context__downTrain] = Context__downNullCmd;
            trainMoveAuthority__downBan();
        }
    }
}

void rlcMain__entranceClosedChange(int32_t enActParameter)
{
    barrierStates__enBarrierClosed(enActParameter);
}

void rlcMain__exitClosingChange(void)
{
    {
        Context__TRAIN_POSITION localUpTrainPosition;
        Context__TRAIN_POSITION localDownTrainPosition;
        Context__BARRIER_STATE localEnBarrier;
        Context__BARRIER_STATE localExBarrier;
        
        localUpTrainPosition = rlcMain__trainPosition_r[Context__upTrain];
        localDownTrainPosition = rlcMain__trainPosition_r[Context__downTrain];
        barrierStates__outputBarrierState(&localEnBarrier, &localExBarrier);
        if((((((localUpTrainPosition == Context__upApproaching) ||
                        (localUpTrainPosition == Context__upClosing)) ||
                    (localDownTrainPosition == Context__downApproaching)) ||
                (localDownTrainPosition == Context__downClosing))) &&
        (localEnBarrier == Context__closed))
        {
            barrierStates__exBarrierClosing();
            rlcMain__exitSignal = Context__exitRed;
        }
    }
}

void rlcMain__exitClosedChange(int32_t exActParameter)
{
    barrierStates__exBarrierClosed(exActParameter);
}

void rlcMain__enExOpeningChange(void)
{
    {
        Context__TRAIN_POSITION localUpTrainPosition;
        Context__TRAIN_POSITION localDownTrainPosition;
        
        localUpTrainPosition = rlcMain__trainPosition_r[Context__upTrain];
        localDownTrainPosition = rlcMain__trainPosition_r[Context__downTrain];
        if((((localUpTrainPosition == Context__upExit) ||
                (localUpTrainPosition == Context__upInitialisation))) &&
        (((localDownTrainPosition == Context__downExit) ||
                (localDownTrainPosition == Context__downInitialisation))))
        {
            barrierStates__enExBarrierOpening();
            rlcMain__enSignal = Context__enWhite;
            rlcMain__exitSignal = Context__exitWhite;
        }
    }
}

void rlcMain__entranceOpenChange(int32_t enActParameter)
{
    barrierStates__enBarrierOpen(enActParameter);
}

void rlcMain__exitOpenChange(int32_t exActParameter)
{
    barrierStates__exBarrierOpen(exActParameter);
}

